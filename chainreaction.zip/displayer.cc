#include "header.h"
#include <SDL.h>

class coordinates { //coordinates class
public:
  coordinates(const int& x,const int& y):x(x) ,y(y) { }
  int x; //x
  int y; //y
};

class displayer {
public:
  SDL_Window
};
