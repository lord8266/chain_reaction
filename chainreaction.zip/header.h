#ifndef DONE
#define DONE 1
#include <iostream>
#include <vector>
#include <set>
#include <string>
#include <map>

using std::pair;
using std::set;
using std::map;
using std::string;
using std::cin;
using std::cout;
using std::string;
using std::endl;
using std::vector;
using std::begin;
using std::end;

#endif
